USE salary_survey;
SELECT industry, gender, ROUND(AVG(annual_salary), 2) AS avg_salary
FROM salaries
GROUP BY industry, gender
ORDER BY industry, gender;

SELECT job_title,
       ROUND(SUM(annual_salary), 2) AS total_salary
FROM salaries
GROUP BY job_title
ORDER BY total_salary DESC
LIMIT 15;

SELECT highest_level_of_education_completed AS education,
       ROUND(AVG(annual_salary), 2) AS avg_salary,
       ROUND(MIN(annual_salary), 2) AS min_salary,
       ROUND(MAX(annual_salary), 2) AS max_salary
FROM salaries
GROUP BY highest_level_of_education_completed
ORDER BY avg_salary DESC;
SELECT industry,
       years_of_professional_experience_overall AS experience,
       COUNT(*) AS num_employees
FROM salaries
GROUP BY industry, years_of_professional_experience_overall
ORDER BY industry, experience;

SELECT age_range, ROUND(AVG(annual_salary), 2) AS avg_salary
FROM salaries
GROUP BY age_range
ORDER BY avg_salary DESC;

WITH ranked AS (
  SELECT country, job_title, annual_salary,
         ROW_NUMBER() OVER (PARTITION BY country ORDER BY annual_salary DESC) AS rn
  FROM salaries
)
SELECT country, job_title, annual_salary
FROM ranked
WHERE rn = 1;

SELECT city, ROUND(AVG(annual_salary), 2) AS avg_salary
FROM salaries
GROUP BY city
ORDER BY avg_salary DESC
LIMIT 10;

SELECT gender,
       ROUND(100 * SUM(CASE WHEN additional_monetary_compensation > 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS bonus_percent
FROM salaries
GROUP BY gender;

SELECT years_of_professional_experience_overall AS experience,
       ROUND(AVG(annual_salary), 2) AS avg_salary,
       COUNT(*) AS employee_count
FROM salaries
GROUP BY years_of_professional_experience_overall
ORDER BY avg_salary DESC;

SELECT industry, gender, highest_level_of_education_completed AS education,
       ROUND(AVG(annual_salary), 2) AS avg_salary
FROM salaries
GROUP BY industry, gender, highest_level_of_education_completed
ORDER BY industry, gender, avg_salary DESC;

